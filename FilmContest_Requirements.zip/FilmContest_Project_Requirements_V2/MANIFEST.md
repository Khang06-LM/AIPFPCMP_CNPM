# MANIFEST — Hồ sơ được tạo

- 1 README gốc, 1 Check-list và hướng dẫn dẫn đường.
- **18 Functional Requirements** tách file: FR-01..FR-18.
- **8 Non-functional Requirements** tách file: NFR-01..NFR-08.
- Entity Catalogue, Data Dictionary, ERD Mermaid, Business Rules.
- Problem/Context/Flow, Governance/Change, Traceability, Test Strategy/Matrix/E2E, Feasibility/Capacity/Risk.
- BE và FE README.
- 8 Skill có `SKILL.md` trong `Skills/`.
- Bảng CSV 69 FPC Story ước lượng giờ minh họa để nhóm điều chỉnh.

> Trạng thái tất cả yêu cầu: Draft; không có code thực, URL Jira/GitHub thật, test PASS hoặc benchmark được suy ra từ tài liệu nguồn. Cần owner review và cập nhật.
