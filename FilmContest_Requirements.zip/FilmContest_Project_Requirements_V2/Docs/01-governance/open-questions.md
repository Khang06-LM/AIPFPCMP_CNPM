# DEC-01 — Open Questions / Decision Log (phải hỏi/duyệt)

> Danh sách câu hỏi **chưa có câu trả lời chính thức trong hai tài liệu nguồn**. Không được tự biến câu trả lời đề xuất thành một “requirement thầy giao”. Mỗi quyết định cập nhật file này + FR liên quan.

| ID | Quyết định cần chốt | Tác động | Phương án đề xuất để thảo luận | Owner | Trạng thái |
|---|---|---|---|---|---|
| D-01 | Mobile Flutter bắt buộc hay Web responsive đủ? | Scope, TV3, estimate | Ưu tiên Web responsive; hỏi GV trước khi bỏ Mobile | TV1 | TBD |
| D-02 | Số bài tối đa mỗi cuộc thi/hạng mục? Có tái sử dụng frame không? | Submission unique/DB | Cấu hình theo ContestRule, chưa cố định số | TV1/TV4 | TBD |
| D-03 | Enrollment auto-approve hay organizer duyệt? | FR-04 flow | Cho cờ `requires_approval` | TV4 | TBD |
| D-04 | Loại file/cỡ ảnh tối đa/tối thiểu? | FR-06/07, storage quota | JPEG trước, TIFF cân nhắc; giới hạn theo rule | TV2/TV3 | TBD |
| D-05 | Ít nhất mấy Judge/vòng, multi-round đến đâu? | FR-09/10/11 | MVP một round chuẩn, thêm multi-round nếu đủ giờ | TV4 | TBD |
| D-06 | Công thức tổng hợp điểm, hòa điểm, thiếu phiếu? | FR-10/11 | Trung bình có trọng số, tie-break cần quy chế | TV2/TV4 | TBD |
| D-07 | Negative/contact sheet lúc nào bắt buộc? | FR-05/06/08 | Mặc định tùy chọn, contest có thể yêu cầu | TV1 | TBD |
| D-08 | Ai cho phép công khai và lưu bao lâu? | Archive/AI privacy | Quyền công bố riêng; retention do GV/nhóm duyệt | TV1/TV3 | TBD |
| D-09 | AI-generated detector có phải demo chạy thực tế? | AI nghiên cứu, chi phí | Làm PoC, chỉ cảnh báo, fallback manual | TV5 | TBD |
| D-10 | Hạn nộp chính thức môn học? | Sprint 4 / cut scope | Không xem 06/12 là được xác nhận nếu GV chưa duyệt | TV1 | TBD |
| D-11 | Backend cuối cùng Express hay ASP.NET Core? | README/api setup | Theo năng lực TV2, chốt trước code sâu | TV2 | TBD |
| D-12 | Tên chính thức và link Jira/GitHub repo? | Traceability | Điền sau khi tạo dự án | TV1 | TBD |

## Quy trình đóng quyết định
1. Ghi bằng chứng từ giảng viên/nhóm (buổi học/tin nhắn), người xác nhận, thời gian.
2. Cập nhật ô trạng thái `APPROVED / REJECTED / TBD`.
3. Sửa cùng PR: FR, BR, Entity, AC/TC, scope/hours và Story liên quan.
4. Không “xóa câu hỏi khỏi lịch sử”; lưu lý do ở change log.
