# FR-04 — Đăng ký tham gia và phê duyệt đăng ký

> **Trạng thái:** DRAFT / REVIEW REQUIRED · **Bản:** 0.9 · **Ngày chuẩn bị:** 28/10/2026  
> **Đây là đặc tả yêu cầu đề xuất, KHÔNG phải chức năng đã triển khai hoặc kết quả kiểm thử đã đạt.**

## 1. Thẻ nhận diện, truy vết và nguồn gốc

| Thuộc tính | Nội dung |
| --- | --- |
| ID | FR-04 |
| Nhóm nghiệp vụ | Core Flow 2 |
| Người dùng/actor | Participant; Contest Organizer |
| Chủ sở hữu tài liệu | TV3 – Hoàng Duy Khánh (FE); TV4 – Nguyễn Khánh Hiền (phê duyệt) |
| Mức ưu tiên đề xuất | MUST – lõi |
| Jira trong kế hoạch (chưa xác nhận key thực) | FPC-17; FPC-19 |
| Nguồn và mức suy diễn | [G] Participant đăng ký, Organizer quản lý hồ sơ; [P] EP-3/EP-4 |
| Phụ thuộc | FR-01; FR-03 |
| Entity | Enrollment; Contest; User |
| Trạng thái đáp ứng | Chưa có bằng chứng triển khai, test hoặc demo – cần điền link PR / test / staging |

**Quy ước nguồn:** `[G]` = nội dung từ đề tài giảng viên; `[P]` = kế hoạch nhóm; `[D]` = phân tích/thiết kế do nhóm đề xuất, cần xác nhận. Các giới hạn số lượng, thời gian và chính sách nghiệp vụ không ghi trong G/P sẽ là **TBD**, không được trình bày như yêu cầu giảng viên đã chốt.

## 2. Vấn đề, giá trị nghiệp vụ và ranh giới

**Vấn đề cần giải quyết:** Trong quy trình thu bài và tổ chức cuộc thi ảnh phim bằng các công cụ rời rạc, nghiệp vụ **đăng ký tham gia và phê duyệt đăng ký** thiếu dữ liệu và trạng thái tập trung, khó truy vết quyền và kết quả xử lý.

**Kết quả kỳ vọng:** Người dùng thuộc vai trò `Participant; Contest Organizer` thực hiện được hành vi được cấp quyền; hệ thống lưu và trả trạng thái nhất quán, có cơ sở kiểm thử, có dữ liệu phục vụ các bước nghiệp vụ sau.

**Trong phạm vi:** Đăng ký tham gia và phê duyệt đăng ký; xử lý đúng quyền, dữ liệu hợp lệ, trường hợp lỗi và dấu vết kiểm thử.

**Ngoài phạm vi / chỉ làm sau:** Không triển khai xác minh danh tính ngoài đời thực ở MVP.

## 3. Tiền điều kiện, dữ liệu và hậu điều kiện

### 3.1 Tiền điều kiện (Preconditions)
- Tài khoản Participant hợp lệ, cuộc thi đang cho đăng ký.

### 3.2 Đầu vào (Inputs)
- ['contest_id, participant_id; kết quả trạng thái đăng ký']
- Tất cả `user_id`, `role`, chủ sở hữu và thời gian thao tác phải được BE đối chiếu từ phiên xác thực / cơ sở dữ liệu, **không tin giá trị giả mạo từ client**.
- Dữ liệu thiếu chính sách bắt buộc hoặc ngưỡng (`TBD`) phải hỏi giảng viên/nhóm trước khi khóa Acceptance Criteria.

### 3.3 Đầu ra (Outputs)
- Thành công: `id` tài nguyên, `status`, `updated_at`, dữ liệu công khai theo quyền; frontend có thông báo hành động thành công.
- Thất bại: mã lỗi ổn định, thông điệp dễ hiểu, HTTP status phù hợp (401/403/404/409/422/5xx tùy tình huống); không rò dữ liệu nhạy cảm.
- Có bản ghi liên kết Entity: **Enrollment; Contest; User** theo sơ đồ đề xuất tại [Entity & Data Dictionary](../../03-domain/entities.md).

### 3.4 Hậu điều kiện (Postconditions)
- **Thành công:** trạng thái nghiệp vụ được ghi nhận nhất quán; hành động sau có thể sử dụng dữ liệu đúng quyền.
- **Thất bại:** không có tài nguyên “nửa thành công” được coi là hoàn tất; lỗi cần retry/rollback được ghi nhận và phân biệt với bài nộp/điểm số không hợp lệ.

## 4. Luồng nghiệp vụ chính (Main Success Scenario / Happy Case)

1. Participant xem danh sách cuộc thi và điều kiện tham gia.
2. Chọn cuộc thi, bấm Đăng ký.
3. Hệ thống kiểm tra điều kiện, hạn đăng ký và đăng ký trùng.
4. Hệ thống tạo Enrollment với trạng thái PENDING hoặc APPROVED tùy cấu hình.
5. Organizer xem danh sách, phê duyệt/từ chối khi chính sách yêu cầu.
6. Participant theo dõi trạng thái, chỉ được nộp bài khi Enrollment hợp lệ.

**Kết quả quan sát được khi demo:** người phụ trách thao tác theo từng bước; mở dữ liệu kết quả hoặc nhật ký API để chứng minh trạng thái, quan hệ Entity và quyền truy cập đã thay đổi chính xác.

## 5. Các luồng thay thế, ngoại lệ và Unhappy Case

| Mã nhánh | Điều kiện kích hoạt | Xử lý bắt buộc | Kết quả/hậu điều kiện |
| --- | --- | --- | --- |
| EX-FR-04-01 | Đã đăng ký cuộc thi | Trả trạng thái cũ; không tạo Enrollment thứ hai. | Idempotent. |
| EX-FR-04-02 | Cuộc thi hết hạn đăng ký | Không nhận đăng ký mới. | Trạng thái không đổi. |
| EX-FR-04-03 | Tài khoản bị khóa | Trả 403. | Không có Enrollment. |
| EX-FR-04-04 | Organizer từ chối đăng ký | Lưu lý do tối thiểu, Participant xem được trạng thái. | Không cho nộp bài. |
| EX-FR-04-05 | Nhiều request cùng lúc | Unique constraint/transaction chống tạo bản ghi trùng. | Chỉ một Enrollment. |

**Nguyên tắc kiểm soát lỗi:** Đối với các nhánh trên, nhóm cần có test kiểm chứng cả ở tầng UI và API. FE chỉ giúp người dùng hiểu lỗi; **BE mới là nơi chặn thao tác không hợp lệ**. Nếu có lỗi phụ thuộc bên ngoài (AI/cloud), tuyệt đối không quy kết ngay người dùng gian lận hoặc sai dữ liệu.

## 6. Quy tắc nghiệp vụ và điều kiện còn phải quyết định

1. **[D – đề xuất, cần duyệt]** BR-12: Không tự tạo nhiều đăng ký trùng cho cùng một cuộc thi nếu chính sách mỗi người một đăng ký.
2. **[D – đề xuất, cần duyệt]** BR-13: Trạng thái đăng ký tách biệt trạng thái Submission.
3. **[D – đề xuất, cần duyệt]** BR-14: Luồng tự động duyệt hoặc duyệt thủ công phải được thầy/nhóm xác nhận.

**Chốt rule:** Mỗi Business Rule (BR) trên phải có người xác nhận. Khi đổi rule, cập nhật file này, [Business Rules](../../03-domain/business-rules.md), Test Case và Jira Story liên quan bằng Pull Request.

## 7. Dữ liệu, quyền và tích hợp với các chức năng khác

- **Entities tham gia:** `Enrollment; Contest; User`. Xem [Entity Catalogue](../../03-domain/entities.md) và [Data Dictionary](../../03-domain/data-dictionary.md).
- **Dependency trước:** [FR-01](../functional/FR-01-authentication-rbac.md); [FR-03](../functional/FR-03-contest-configuration.md).
- **Dependency sau:** kiểm tra trong [Ma trận truy vết](../../04-traceability/requirements-matrix.md) và [Luồng nghiệp vụ](../../00-overview/end-to-end-flows.md).
- **Quyền:** BE kiểm tra actor role, trạng thái đối tượng, phạm vi contest và owner/assignment trước khi đọc hoặc sửa dữ liệu.
- **Nguyên tắc đồng nhất:** khóa ngoại không được đứt; tránh retry sinh bản ghi trùng; mọi transition quan trọng có thời gian, actor và lịch sử kiểm toán phù hợp.

## 8. Hướng đáp ứng bằng phần mềm — thiết kế đề xuất (không phải đã code)

**API dự kiến:** `POST /contests/{id}/enrollments; GET /me/enrollments; PATCH /enrollments/{id}/decision`.

1. **FE** thể hiện đúng trạng thái tải/trống/thành công/lỗi, disable nút không hợp lệ nhưng không thay thế kiểm tra BE; mapping trường đầu vào vào payload thống nhất.
2. **BE** kiểm tra JWT/RBAC, ràng buộc dữ liệu, state transition, transaction/idempotency khi cần; trả lỗi machine-readable và không ghi secret trong log.
3. **DB / Storage** sử dụng các FK/unique/version và giới hạn truy cập trong [Data Dictionary](../../03-domain/data-dictionary.md). Với ảnh, tách metadata trong DB và binary trong object storage.
4. **Integration** ghi rõ điểm gọi sang module khác, contract request/response và failure fallback; việc nào chưa có endpoint phải ghi `TBD`, không bịa API đã chạy.

**Dấu hiệu đáp ứng thực tế khi hoàn thiện:** link PR merged + commit + CI xanh + bộ test thực chạy + màn hình/demo trên staging + bản ghi bằng chứng. Hiện thời **CHƯA CÓ** các bằng chứng này trong hai tài liệu nguồn.

## 9. Acceptance Criteria (tiêu chí nghiệm thu)

| Mã | Điều kiện đạt (quan sát/kiểm thử được) | Cách chứng minh dự kiến |
| --- | --- | --- |
| AC-FR-04-01 | Tài khoản hợp lệ có thể tạo một Enrollment cho cuộc thi mở. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-04-02 | Đăng ký trùng không làm tăng số lượng bản ghi. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-04-03 | Enrollment bị từ chối không thể nộp ảnh. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-04-04 | Tình trạng đăng ký hiển thị giống nhau ở Participant và Organizer. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-04-05 | Người khác không thể xem dữ liệu đăng ký riêng tư trái quyền. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-04-06 | Khi đã đăng ký cuộc thi, hệ thống phải: Trả trạng thái cũ; không tạo Enrollment thứ hai. Kết quả: Idempotent. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-04-07 | Khi cuộc thi hết hạn đăng ký, hệ thống phải: Không nhận đăng ký mới. Kết quả: Trạng thái không đổi. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-04-08 | Khi tài khoản bị khóa, hệ thống phải: Trả 403. Kết quả: Không có Enrollment. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-04-09 | Khi organizer từ chối đăng ký, hệ thống phải: Lưu lý do tối thiểu, Participant xem được trạng thái. Kết quả: Không cho nộp bài. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-04-10 | Khi nhiều request cùng lúc, hệ thống phải: Unique constraint/transaction chống tạo bản ghi trùng. Kết quả: Chỉ một Enrollment. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |

> Chưa đánh dấu `Pass` cho bất kỳ AC nào trước khi chạy test thật. Sau khi làm phần mềm, điền `Expected / Actual / Evidence / Pass-Fail / Tester / Date` trong nhật ký test.

## 10. Test Scenarios (cả happy và unhappy)

| Test ID | Nhóm | Dữ liệu / thao tác | AC tham chiếu dự kiến | Kết quả mong đợi |
| --- | --- | --- | --- | --- |
| TC-FR-04-01 | Happy | Điều kiện đầu đáp ứng; thực hiện đầy đủ main flow | AC-FR-04-01 | Thao tác thành công, bản ghi đúng quyền, trạng thái hợp lệ |
| TC-FR-04-02 | Unhappy / alternate | Đã đăng ký cuộc thi | AC-FR-04-06 | Idempotent. |
| TC-FR-04-03 | Unhappy / alternate | Cuộc thi hết hạn đăng ký | AC-FR-04-07 | Trạng thái không đổi. |
| TC-FR-04-04 | Unhappy / alternate | Tài khoản bị khóa | AC-FR-04-08 | Không có Enrollment. |
| TC-FR-04-05 | Unhappy / alternate | Organizer từ chối đăng ký | AC-FR-04-09 | Không cho nộp bài. |
| TC-FR-04-06 | Unhappy / alternate | Nhiều request cùng lúc | AC-FR-04-10 | Chỉ một Enrollment. |

**Hướng test:** chuẩn bị seed có ID rõ ràng; chạy happy case, lỗi validation, lỗi phân quyền, lỗi trạng thái và lỗi dịch vụ phụ thuộc; lưu ảnh màn hình/log (ẩn thông tin nhạy cảm). Test Case chi tiết chính thức được theo dõi tại [Test Matrix](../../05-quality/test-matrix.md).

## 11. Khả thi, giới hạn, rủi ro và phương án fallback

- **Đánh giá sơ bộ:** Khả thi cao; cần quyết định duyệt tự động/hay thủ công.
- **Giới hạn giải pháp:** Không triển khai xác minh danh tính ngoài đời thực ở MVP.
- **Ước lượng thử để lập kế hoạch:** 14 giờ/người bao gồm phân tích, triển khai và test tối thiểu; **chưa phải cam kết**. Phải hiệu chỉnh theo năng lực và thời gian rảnh thực tế, xem [Capacity & Estimation](../../06-feasibility/capacity-estimation.md).
- **Tiêu chí xác nhận khả thi:** có PoC hoặc test trên dữ liệu mẫu và bằng chứng cấu hình thực; trường hợp không đạt phải nêu rõ phần cắt giảm và hỏi giảng viên nếu thuộc yêu cầu gốc.
- **Trách nhiệm quyết định:** TV1 BA/PM xác nhận nghiệp vụ, TV2 xác nhận tác động API/DB, owner module kiểm tra test, giảng viên duyệt những ràng buộc phạm vi quan trọng.

## 12. Checklist review riêng cho yêu cầu này

- [ ] Actor và quyền được mô tả rõ, có kiểm tra trái quyền.
- [ ] Tất cả bước Main Flow có trạng thái dữ liệu sau bước.
- [ ] Có ít nhất một happy case và các unhappy case thực tế ở mục 5.
- [ ] Đã đối chiếu BR với thể lệ cuộc thi hoặc có quyết định `TBD`.
- [ ] Entity và khóa tham chiếu khớp Data Dictionary.
- [ ] Mỗi AC có test dự kiến, chưa nhầm test design với test pass.
- [ ] Link Jira chính thức, PR, demo, test được cập nhật khi có.
- [ ] Được owner + reviewer chéo duyệt, trạng thái chuyển sang APPROVED.

**Chứng cứ liên kết:** [SRS Index](../README.md) · [Requirements Management](../../01-governance/requirements-management.md) · [Traceability](../../04-traceability/requirements-matrix.md) · [Feasibility](../../06-feasibility/feasibility-study.md).
