# FR-10 — Chấm điểm đa tiêu chí, nhận xét và chốt theo vòng

> **Trạng thái:** DRAFT / REVIEW REQUIRED · **Bản:** 0.9 · **Ngày chuẩn bị:** 28/10/2026  
> **Đây là đặc tả yêu cầu đề xuất, KHÔNG phải chức năng đã triển khai hoặc kết quả kiểm thử đã đạt.**

## 1. Thẻ nhận diện, truy vết và nguồn gốc

| Thuộc tính | Nội dung |
| --- | --- |
| ID | FR-10 |
| Nhóm nghiệp vụ | Core Flow 4 |
| Người dùng/actor | Judge; Contest Organizer |
| Chủ sở hữu tài liệu | TV4 – Nguyễn Khánh Hiền |
| Mức ưu tiên đề xuất | MUST – lõi |
| Jira trong kế hoạch (chưa xác nhận key thực) | FPC-30; FPC-31 |
| Nguồn và mức suy diễn | [G] chấm theo tiêu chí grain/tonal range... và nhiều vòng; [P] EP-7 |
| Phụ thuộc | FR-03; FR-09; FR-08 |
| Entity | ScoreSheet; CriterionScore; Criterion; JudgeAssignment; ContestRound |
| Trạng thái đáp ứng | Chưa có bằng chứng triển khai, test hoặc demo – cần điền link PR / test / staging |

**Quy ước nguồn:** `[G]` = nội dung từ đề tài giảng viên; `[P]` = kế hoạch nhóm; `[D]` = phân tích/thiết kế do nhóm đề xuất, cần xác nhận. Các giới hạn số lượng, thời gian và chính sách nghiệp vụ không ghi trong G/P sẽ là **TBD**, không được trình bày như yêu cầu giảng viên đã chốt.

## 2. Vấn đề, giá trị nghiệp vụ và ranh giới

**Vấn đề cần giải quyết:** Trong quy trình thu bài và tổ chức cuộc thi ảnh phim bằng các công cụ rời rạc, nghiệp vụ **chấm điểm đa tiêu chí, nhận xét và chốt theo vòng** thiếu dữ liệu và trạng thái tập trung, khó truy vết quyền và kết quả xử lý.

**Kết quả kỳ vọng:** Người dùng thuộc vai trò `Judge; Contest Organizer` thực hiện được hành vi được cấp quyền; hệ thống lưu và trả trạng thái nhất quán, có cơ sở kiểm thử, có dữ liệu phục vụ các bước nghiệp vụ sau.

**Trong phạm vi:** Chấm điểm đa tiêu chí, nhận xét và chốt theo vòng; xử lý đúng quyền, dữ liệu hợp lệ, trường hợp lỗi và dấu vết kiểm thử.

**Ngoài phạm vi / chỉ làm sau:** Không bảo đảm loại bỏ thiên lệch chủ quan của giám khảo; cần định nghĩa xử lý đồng điểm, thiếu phiếu.

## 3. Tiền điều kiện, dữ liệu và hậu điều kiện

### 3.1 Tiền điều kiện (Preconditions)
- Submission Approved, Judge được phân công, criterion đã khóa phiên bản.

### 3.2 Đầu vào (Inputs)
- ['submission_id, round_id, criterion scores, comment, draft/finalize']
- Tất cả `user_id`, `role`, chủ sở hữu và thời gian thao tác phải được BE đối chiếu từ phiên xác thực / cơ sở dữ liệu, **không tin giá trị giả mạo từ client**.
- Dữ liệu thiếu chính sách bắt buộc hoặc ngưỡng (`TBD`) phải hỏi giảng viên/nhóm trước khi khóa Acceptance Criteria.

### 3.3 Đầu ra (Outputs)
- Thành công: `id` tài nguyên, `status`, `updated_at`, dữ liệu công khai theo quyền; frontend có thông báo hành động thành công.
- Thất bại: mã lỗi ổn định, thông điệp dễ hiểu, HTTP status phù hợp (401/403/404/409/422/5xx tùy tình huống); không rò dữ liệu nhạy cảm.
- Có bản ghi liên kết Entity: **ScoreSheet; CriterionScore; Criterion; JudgeAssignment; ContestRound** theo sơ đồ đề xuất tại [Entity & Data Dictionary](../../03-domain/entities.md).

### 3.4 Hậu điều kiện (Postconditions)
- **Thành công:** trạng thái nghiệp vụ được ghi nhận nhất quán; hành động sau có thể sử dụng dữ liệu đúng quyền.
- **Thất bại:** không có tài nguyên “nửa thành công” được coi là hoàn tất; lỗi cần retry/rollback được ghi nhận và phân biệt với bài nộp/điểm số không hợp lệ.

## 4. Luồng nghiệp vụ chính (Main Success Scenario / Happy Case)

1. Judge mở bài được phân công; xem ảnh và tiêu chí với trọng số.
2. Judge nhập điểm từng tiêu chí trong miền cho phép, thêm nhận xét.
3. FE hiển thị tổng/tạm tính minh họa nhưng BE tính lại khi lưu.
4. Judge lưu nháp ScoreSheet; có thể sửa khi chưa Finalized.
5. Judge nhấn Chốt; BE validate đủ tiêu chí, quyền và thời hạn vòng.
6. BE lưu từng CriterionScore với criterion_version, chuyển FINALIZED và ghi audit.

**Kết quả quan sát được khi demo:** người phụ trách thao tác theo từng bước; mở dữ liệu kết quả hoặc nhật ký API để chứng minh trạng thái, quan hệ Entity và quyền truy cập đã thay đổi chính xác.

## 5. Các luồng thay thế, ngoại lệ và Unhappy Case

| Mã nhánh | Điều kiện kích hoạt | Xử lý bắt buộc | Kết quả/hậu điều kiện |
| --- | --- | --- | --- |
| EX-FR-10-01 | Điểm vượt thang | BE từ chối 422 và chỉ rõ tiêu chí. | Không lưu điểm không hợp lệ. |
| EX-FR-10-02 | Thiếu một tiêu chí khi chốt | Cho lưu nháp; không cho Finalized. | Không đưa vào tổng kết. |
| EX-FR-10-03 | Judge chấm bài không được gán | Trả 403. | Không ghi ScoreSheet. |
| EX-FR-10-04 | Gửi 2 request chốt liên tiếp | Lock/version chống cập nhật đúp. | Một trạng thái Finalized. |
| EX-FR-10-05 | Organizer đổi trọng số sau khi có điểm | Giữ bản tiêu chí theo version; không tính lại trái phép. | Có thể tái lập điểm. |
| EX-FR-10-06 | Judge cố sửa sau Finalized | Trả lỗi 409 với hướng dẫn yêu cầu mở lại. | Bảo toàn kết quả. |

**Nguyên tắc kiểm soát lỗi:** Đối với các nhánh trên, nhóm cần có test kiểm chứng cả ở tầng UI và API. FE chỉ giúp người dùng hiểu lỗi; **BE mới là nơi chặn thao tác không hợp lệ**. Nếu có lỗi phụ thuộc bên ngoài (AI/cloud), tuyệt đối không quy kết ngay người dùng gian lận hoặc sai dữ liệu.

## 6. Quy tắc nghiệp vụ và điều kiện còn phải quyết định

1. **[D – đề xuất, cần duyệt]** BR-34: Điểm từng tiêu chí trong [0,max_score] theo thang điểm cấu hình.
2. **[D – đề xuất, cần duyệt]** BR-35: Công thức điểm chuẩn hóa và trọng số phải chốt, BE là nguồn tính điểm.
3. **[D – đề xuất, cần duyệt]** BR-36: Điểm đã Finalized không sửa trực tiếp; phải qua quy trình mở lại có audit nếu được phép.
4. **[D – đề xuất, cần duyệt]** BR-37: Không hiển thị điểm Judge khác trước khi chốt nếu chính sách chấm độc lập.

**Chốt rule:** Mỗi Business Rule (BR) trên phải có người xác nhận. Khi đổi rule, cập nhật file này, [Business Rules](../../03-domain/business-rules.md), Test Case và Jira Story liên quan bằng Pull Request.

## 7. Dữ liệu, quyền và tích hợp với các chức năng khác

- **Entities tham gia:** `ScoreSheet; CriterionScore; Criterion; JudgeAssignment; ContestRound`. Xem [Entity Catalogue](../../03-domain/entities.md) và [Data Dictionary](../../03-domain/data-dictionary.md).
- **Dependency trước:** [FR-03](../functional/FR-03-contest-configuration.md); [FR-09](../functional/FR-09-judge-assignment.md); [FR-08](../functional/FR-08-manual-review.md).
- **Dependency sau:** kiểm tra trong [Ma trận truy vết](../../04-traceability/requirements-matrix.md) và [Luồng nghiệp vụ](../../00-overview/end-to-end-flows.md).
- **Quyền:** BE kiểm tra actor role, trạng thái đối tượng, phạm vi contest và owner/assignment trước khi đọc hoặc sửa dữ liệu.
- **Nguyên tắc đồng nhất:** khóa ngoại không được đứt; tránh retry sinh bản ghi trùng; mọi transition quan trọng có thời gian, actor và lịch sử kiểm toán phù hợp.

## 8. Hướng đáp ứng bằng phần mềm — thiết kế đề xuất (không phải đã code)

**API dự kiến:** `PUT /judge/scoresheets/{id}; POST /judge/scoresheets/{id}/finalize`.

1. **FE** thể hiện đúng trạng thái tải/trống/thành công/lỗi, disable nút không hợp lệ nhưng không thay thế kiểm tra BE; mapping trường đầu vào vào payload thống nhất.
2. **BE** kiểm tra JWT/RBAC, ràng buộc dữ liệu, state transition, transaction/idempotency khi cần; trả lỗi machine-readable và không ghi secret trong log.
3. **DB / Storage** sử dụng các FK/unique/version và giới hạn truy cập trong [Data Dictionary](../../03-domain/data-dictionary.md). Với ảnh, tách metadata trong DB và binary trong object storage.
4. **Integration** ghi rõ điểm gọi sang module khác, contract request/response và failure fallback; việc nào chưa có endpoint phải ghi `TBD`, không bịa API đã chạy.

**Dấu hiệu đáp ứng thực tế khi hoàn thiện:** link PR merged + commit + CI xanh + bộ test thực chạy + màn hình/demo trên staging + bản ghi bằng chứng. Hiện thời **CHƯA CÓ** các bằng chứng này trong hai tài liệu nguồn.

## 9. Acceptance Criteria (tiêu chí nghiệm thu)

| Mã | Điều kiện đạt (quan sát/kiểm thử được) | Cách chứng minh dự kiến |
| --- | --- | --- |
| AC-FR-10-01 | Một Judge được giao có thể lưu nháp điểm cho bài Approved. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-10-02 | Điểm ngoài miền bị từ chối ở API. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-10-03 | Không thể chốt khi thiếu tiêu chí bắt buộc. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-10-04 | Đã chốt không được sửa trực tiếp. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-10-05 | Bản ghi từng điểm liên kết criterion version. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-10-06 | BE tính lại tổng điểm không tin số tiền tính từ client. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-10-07 | Khi điểm vượt thang, hệ thống phải: BE từ chối 422 và chỉ rõ tiêu chí. Kết quả: Không lưu điểm không hợp lệ. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-10-08 | Khi thiếu một tiêu chí khi chốt, hệ thống phải: Cho lưu nháp; không cho Finalized. Kết quả: Không đưa vào tổng kết. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-10-09 | Khi judge chấm bài không được gán, hệ thống phải: Trả 403. Kết quả: Không ghi ScoreSheet. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-10-10 | Khi gửi 2 request chốt liên tiếp, hệ thống phải: Lock/version chống cập nhật đúp. Kết quả: Một trạng thái Finalized. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-10-11 | Khi organizer đổi trọng số sau khi có điểm, hệ thống phải: Giữ bản tiêu chí theo version; không tính lại trái phép. Kết quả: Có thể tái lập điểm. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-10-12 | Khi judge cố sửa sau finalized, hệ thống phải: Trả lỗi 409 với hướng dẫn yêu cầu mở lại. Kết quả: Bảo toàn kết quả. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |

> Chưa đánh dấu `Pass` cho bất kỳ AC nào trước khi chạy test thật. Sau khi làm phần mềm, điền `Expected / Actual / Evidence / Pass-Fail / Tester / Date` trong nhật ký test.

## 10. Test Scenarios (cả happy và unhappy)

| Test ID | Nhóm | Dữ liệu / thao tác | AC tham chiếu dự kiến | Kết quả mong đợi |
| --- | --- | --- | --- | --- |
| TC-FR-10-01 | Happy | Điều kiện đầu đáp ứng; thực hiện đầy đủ main flow | AC-FR-10-01 | Thao tác thành công, bản ghi đúng quyền, trạng thái hợp lệ |
| TC-FR-10-02 | Unhappy / alternate | Điểm vượt thang | AC-FR-10-07 | Không lưu điểm không hợp lệ. |
| TC-FR-10-03 | Unhappy / alternate | Thiếu một tiêu chí khi chốt | AC-FR-10-08 | Không đưa vào tổng kết. |
| TC-FR-10-04 | Unhappy / alternate | Judge chấm bài không được gán | AC-FR-10-09 | Không ghi ScoreSheet. |
| TC-FR-10-05 | Unhappy / alternate | Gửi 2 request chốt liên tiếp | AC-FR-10-10 | Một trạng thái Finalized. |
| TC-FR-10-06 | Unhappy / alternate | Organizer đổi trọng số sau khi có điểm | AC-FR-10-11 | Có thể tái lập điểm. |
| TC-FR-10-07 | Unhappy / alternate | Judge cố sửa sau Finalized | AC-FR-10-12 | Bảo toàn kết quả. |

**Hướng test:** chuẩn bị seed có ID rõ ràng; chạy happy case, lỗi validation, lỗi phân quyền, lỗi trạng thái và lỗi dịch vụ phụ thuộc; lưu ảnh màn hình/log (ẩn thông tin nhạy cảm). Test Case chi tiết chính thức được theo dõi tại [Test Matrix](../../05-quality/test-matrix.md).

## 11. Khả thi, giới hạn, rủi ro và phương án fallback

- **Đánh giá sơ bộ:** Khả thi trung bình; nên ưu tiên 1 round được chấm đúng, sau đó thêm round transitions.
- **Giới hạn giải pháp:** Không bảo đảm loại bỏ thiên lệch chủ quan của giám khảo; cần định nghĩa xử lý đồng điểm, thiếu phiếu.
- **Ước lượng thử để lập kế hoạch:** 28 giờ/người bao gồm phân tích, triển khai và test tối thiểu; **chưa phải cam kết**. Phải hiệu chỉnh theo năng lực và thời gian rảnh thực tế, xem [Capacity & Estimation](../../06-feasibility/capacity-estimation.md).
- **Tiêu chí xác nhận khả thi:** có PoC hoặc test trên dữ liệu mẫu và bằng chứng cấu hình thực; trường hợp không đạt phải nêu rõ phần cắt giảm và hỏi giảng viên nếu thuộc yêu cầu gốc.
- **Trách nhiệm quyết định:** TV1 BA/PM xác nhận nghiệp vụ, TV2 xác nhận tác động API/DB, owner module kiểm tra test, giảng viên duyệt những ràng buộc phạm vi quan trọng.

## 12. Checklist review riêng cho yêu cầu này

- [ ] Actor và quyền được mô tả rõ, có kiểm tra trái quyền.
- [ ] Tất cả bước Main Flow có trạng thái dữ liệu sau bước.
- [ ] Có ít nhất một happy case và các unhappy case thực tế ở mục 5.
- [ ] Đã đối chiếu BR với thể lệ cuộc thi hoặc có quyết định `TBD`.
- [ ] Entity và khóa tham chiếu khớp Data Dictionary.
- [ ] Mỗi AC có test dự kiến, chưa nhầm test design với test pass.
- [ ] Link Jira chính thức, PR, demo, test được cập nhật khi có.
- [ ] Được owner + reviewer chéo duyệt, trạng thái chuyển sang APPROVED.

**Chứng cứ liên kết:** [SRS Index](../README.md) · [Requirements Management](../../01-governance/requirements-management.md) · [Traceability](../../04-traceability/requirements-matrix.md) · [Feasibility](../../06-feasibility/feasibility-study.md).
