# FR-08 — Duyệt bài và xử lý yêu cầu chỉnh sửa

> **Trạng thái:** DRAFT / REVIEW REQUIRED · **Bản:** 0.9 · **Ngày chuẩn bị:** 28/10/2026  
> **Đây là đặc tả yêu cầu đề xuất, KHÔNG phải chức năng đã triển khai hoặc kết quả kiểm thử đã đạt.**

## 1. Thẻ nhận diện, truy vết và nguồn gốc

| Thuộc tính | Nội dung |
| --- | --- |
| ID | FR-08 |
| Nhóm nghiệp vụ | Core Flow 3 |
| Người dùng/actor | Contest Organizer |
| Chủ sở hữu tài liệu | TV4 – Nguyễn Khánh Hiền |
| Mức ưu tiên đề xuất | MUST – lõi |
| Jira trong kế hoạch (chưa xác nhận key thực) | FPC-28; FPC-42 |
| Nguồn và mức suy diễn | [G] Organizer thẩm định, AI gắn cờ hỗ trợ; [P] EP-6/EP-9 |
| Phụ thuộc | FR-07; FR-13; FR-14 |
| Entity | Submission; ReviewDecision; ValidationReport; AIAnalysis; AuditLog |
| Trạng thái đáp ứng | Chưa có bằng chứng triển khai, test hoặc demo – cần điền link PR / test / staging |

**Quy ước nguồn:** `[G]` = nội dung từ đề tài giảng viên; `[P]` = kế hoạch nhóm; `[D]` = phân tích/thiết kế do nhóm đề xuất, cần xác nhận. Các giới hạn số lượng, thời gian và chính sách nghiệp vụ không ghi trong G/P sẽ là **TBD**, không được trình bày như yêu cầu giảng viên đã chốt.

## 2. Vấn đề, giá trị nghiệp vụ và ranh giới

**Vấn đề cần giải quyết:** Trong quy trình thu bài và tổ chức cuộc thi ảnh phim bằng các công cụ rời rạc, nghiệp vụ **duyệt bài và xử lý yêu cầu chỉnh sửa** thiếu dữ liệu và trạng thái tập trung, khó truy vết quyền và kết quả xử lý.

**Kết quả kỳ vọng:** Người dùng thuộc vai trò `Contest Organizer` thực hiện được hành vi được cấp quyền; hệ thống lưu và trả trạng thái nhất quán, có cơ sở kiểm thử, có dữ liệu phục vụ các bước nghiệp vụ sau.

**Trong phạm vi:** Duyệt bài và xử lý yêu cầu chỉnh sửa; xử lý đúng quyền, dữ liệu hợp lệ, trường hợp lỗi và dấu vết kiểm thử.

**Ngoài phạm vi / chỉ làm sau:** Không thiết kế quy trình khiếu nại nhiều cấp trong MVP nếu giảng viên chưa bắt buộc.

## 3. Tiền điều kiện, dữ liệu và hậu điều kiện

### 3.1 Tiền điều kiện (Preconditions)
- Submission ở trạng thái chờ duyệt; Organizer được cấp quyền cuộc thi.

### 3.2 Đầu vào (Inputs)
- ['submission_id, action approve/reject/request_revision, reason, version']
- Tất cả `user_id`, `role`, chủ sở hữu và thời gian thao tác phải được BE đối chiếu từ phiên xác thực / cơ sở dữ liệu, **không tin giá trị giả mạo từ client**.
- Dữ liệu thiếu chính sách bắt buộc hoặc ngưỡng (`TBD`) phải hỏi giảng viên/nhóm trước khi khóa Acceptance Criteria.

### 3.3 Đầu ra (Outputs)
- Thành công: `id` tài nguyên, `status`, `updated_at`, dữ liệu công khai theo quyền; frontend có thông báo hành động thành công.
- Thất bại: mã lỗi ổn định, thông điệp dễ hiểu, HTTP status phù hợp (401/403/404/409/422/5xx tùy tình huống); không rò dữ liệu nhạy cảm.
- Có bản ghi liên kết Entity: **Submission; ReviewDecision; ValidationReport; AIAnalysis; AuditLog** theo sơ đồ đề xuất tại [Entity & Data Dictionary](../../03-domain/entities.md).

### 3.4 Hậu điều kiện (Postconditions)
- **Thành công:** trạng thái nghiệp vụ được ghi nhận nhất quán; hành động sau có thể sử dụng dữ liệu đúng quyền.
- **Thất bại:** không có tài nguyên “nửa thành công” được coi là hoàn tất; lỗi cần retry/rollback được ghi nhận và phân biệt với bài nộp/điểm số không hợp lệ.

## 4. Luồng nghiệp vụ chính (Main Success Scenario / Happy Case)

1. Organizer mở hàng đợi, lọc trạng thái/cảnh báo.
2. Hệ thống hiển thị ảnh, metadata, validation errors và AI flags kèm giải thích giới hạn.
3. Organizer đối chiếu quy chế và có thể xem tài liệu minh chứng theo quyền.
4. Chọn duyệt/từ chối/yêu cầu bổ sung, nhập lý do khi cần.
5. BE kiểm tra state transition, quyền và chống xử lý đồng thời.
6. BE lưu ReviewDecision và AuditLog; cập nhật trạng thái; thông báo đến Participant.

**Kết quả quan sát được khi demo:** người phụ trách thao tác theo từng bước; mở dữ liệu kết quả hoặc nhật ký API để chứng minh trạng thái, quan hệ Entity và quyền truy cập đã thay đổi chính xác.

## 5. Các luồng thay thế, ngoại lệ và Unhappy Case

| Mã nhánh | Điều kiện kích hoạt | Xử lý bắt buộc | Kết quả/hậu điều kiện |
| --- | --- | --- | --- |
| EX-FR-08-01 | Bài đã duyệt bởi Organizer khác | Phát hiện version mismatch, báo làm mới. | Không ghi đè quyết định. |
| EX-FR-08-02 | Chọn Reject không nhập lý do | BE trả 422, giữ trạng thái trước. | Có đủ audit. |
| EX-FR-08-03 | Nhận AI flag nhưng ảnh vẫn hợp lệ | Organizer có thể Approve kèm ghi chú; log quyết định. | Không auto reject. |
| EX-FR-08-04 | Không tìm được file minh chứng | Báo lỗi hệ thống, cho defer; không kết luận gian lận. | Không loại nhầm. |
| EX-FR-08-05 | Participant nộp lại sau yêu cầu sửa | Tạo version mới hoặc Submission revision theo chính sách. | Bảo toàn quyết định cũ. |

**Nguyên tắc kiểm soát lỗi:** Đối với các nhánh trên, nhóm cần có test kiểm chứng cả ở tầng UI và API. FE chỉ giúp người dùng hiểu lỗi; **BE mới là nơi chặn thao tác không hợp lệ**. Nếu có lỗi phụ thuộc bên ngoài (AI/cloud), tuyệt đối không quy kết ngay người dùng gian lận hoặc sai dữ liệu.

## 6. Quy tắc nghiệp vụ và điều kiện còn phải quyết định

1. **[D – đề xuất, cần duyệt]** BR-27: AI flag không có quyền quyết định loại tác phẩm tự động.
2. **[D – đề xuất, cần duyệt]** BR-28: Một quyết định cuối phải có người thực hiện/thời điểm/lý do khi từ chối.
3. **[D – đề xuất, cần duyệt]** BR-29: Chỉ bài Approved mới được đưa vào danh sách phân công giám khảo.
4. **[D – đề xuất, cần duyệt]** BR-30: Yêu cầu sửa chỉ khả dụng theo quy tắc contest và deadline.

**Chốt rule:** Mỗi Business Rule (BR) trên phải có người xác nhận. Khi đổi rule, cập nhật file này, [Business Rules](../../03-domain/business-rules.md), Test Case và Jira Story liên quan bằng Pull Request.

## 7. Dữ liệu, quyền và tích hợp với các chức năng khác

- **Entities tham gia:** `Submission; ReviewDecision; ValidationReport; AIAnalysis; AuditLog`. Xem [Entity Catalogue](../../03-domain/entities.md) và [Data Dictionary](../../03-domain/data-dictionary.md).
- **Dependency trước:** [FR-07](../functional/FR-07-automatic-validation.md); [FR-13](../functional/FR-13-duplicate-similarity-ai.md); [FR-14](../functional/FR-14-generated-image-ai.md).
- **Dependency sau:** kiểm tra trong [Ma trận truy vết](../../04-traceability/requirements-matrix.md) và [Luồng nghiệp vụ](../../00-overview/end-to-end-flows.md).
- **Quyền:** BE kiểm tra actor role, trạng thái đối tượng, phạm vi contest và owner/assignment trước khi đọc hoặc sửa dữ liệu.
- **Nguyên tắc đồng nhất:** khóa ngoại không được đứt; tránh retry sinh bản ghi trùng; mọi transition quan trọng có thời gian, actor và lịch sử kiểm toán phù hợp.

## 8. Hướng đáp ứng bằng phần mềm — thiết kế đề xuất (không phải đã code)

**API dự kiến:** `GET /organizer/review-queue; POST /submissions/{id}/review; GET /submissions/{id}/review-history`.

1. **FE** thể hiện đúng trạng thái tải/trống/thành công/lỗi, disable nút không hợp lệ nhưng không thay thế kiểm tra BE; mapping trường đầu vào vào payload thống nhất.
2. **BE** kiểm tra JWT/RBAC, ràng buộc dữ liệu, state transition, transaction/idempotency khi cần; trả lỗi machine-readable và không ghi secret trong log.
3. **DB / Storage** sử dụng các FK/unique/version và giới hạn truy cập trong [Data Dictionary](../../03-domain/data-dictionary.md). Với ảnh, tách metadata trong DB và binary trong object storage.
4. **Integration** ghi rõ điểm gọi sang module khác, contract request/response và failure fallback; việc nào chưa có endpoint phải ghi `TBD`, không bịa API đã chạy.

**Dấu hiệu đáp ứng thực tế khi hoàn thiện:** link PR merged + commit + CI xanh + bộ test thực chạy + màn hình/demo trên staging + bản ghi bằng chứng. Hiện thời **CHƯA CÓ** các bằng chứng này trong hai tài liệu nguồn.

## 9. Acceptance Criteria (tiêu chí nghiệm thu)

| Mã | Điều kiện đạt (quan sát/kiểm thử được) | Cách chứng minh dự kiến |
| --- | --- | --- |
| AC-FR-08-01 | Organizer xem hàng đợi và chi tiết một bài. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-08-02 | Approve chỉ thực hiện từ trạng thái cho phép. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-08-03 | Reject yêu cầu lý do và lưu audit. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-08-04 | Trạng thái cùng lý do hiển thị cho Participant theo quyền. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-08-05 | Hai người xử lý cùng lúc không tạo trạng thái trái ngược. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-08-06 | AI flag có thể được Organizer bỏ qua có giải trình. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-08-07 | Khi bài đã duyệt bởi organizer khác, hệ thống phải: Phát hiện version mismatch, báo làm mới. Kết quả: Không ghi đè quyết định. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-08-08 | Khi chọn reject không nhập lý do, hệ thống phải: BE trả 422, giữ trạng thái trước. Kết quả: Có đủ audit. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-08-09 | Khi nhận ai flag nhưng ảnh vẫn hợp lệ, hệ thống phải: Organizer có thể Approve kèm ghi chú; log quyết định. Kết quả: Không auto reject. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-08-10 | Khi không tìm được file minh chứng, hệ thống phải: Báo lỗi hệ thống, cho defer; không kết luận gian lận. Kết quả: Không loại nhầm. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-08-11 | Khi participant nộp lại sau yêu cầu sửa, hệ thống phải: Tạo version mới hoặc Submission revision theo chính sách. Kết quả: Bảo toàn quyết định cũ. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |

> Chưa đánh dấu `Pass` cho bất kỳ AC nào trước khi chạy test thật. Sau khi làm phần mềm, điền `Expected / Actual / Evidence / Pass-Fail / Tester / Date` trong nhật ký test.

## 10. Test Scenarios (cả happy và unhappy)

| Test ID | Nhóm | Dữ liệu / thao tác | AC tham chiếu dự kiến | Kết quả mong đợi |
| --- | --- | --- | --- | --- |
| TC-FR-08-01 | Happy | Điều kiện đầu đáp ứng; thực hiện đầy đủ main flow | AC-FR-08-01 | Thao tác thành công, bản ghi đúng quyền, trạng thái hợp lệ |
| TC-FR-08-02 | Unhappy / alternate | Bài đã duyệt bởi Organizer khác | AC-FR-08-07 | Không ghi đè quyết định. |
| TC-FR-08-03 | Unhappy / alternate | Chọn Reject không nhập lý do | AC-FR-08-08 | Có đủ audit. |
| TC-FR-08-04 | Unhappy / alternate | Nhận AI flag nhưng ảnh vẫn hợp lệ | AC-FR-08-09 | Không auto reject. |
| TC-FR-08-05 | Unhappy / alternate | Không tìm được file minh chứng | AC-FR-08-10 | Không loại nhầm. |
| TC-FR-08-06 | Unhappy / alternate | Participant nộp lại sau yêu cầu sửa | AC-FR-08-11 | Bảo toàn quyết định cũ. |

**Hướng test:** chuẩn bị seed có ID rõ ràng; chạy happy case, lỗi validation, lỗi phân quyền, lỗi trạng thái và lỗi dịch vụ phụ thuộc; lưu ảnh màn hình/log (ẩn thông tin nhạy cảm). Test Case chi tiết chính thức được theo dõi tại [Test Matrix](../../05-quality/test-matrix.md).

## 11. Khả thi, giới hạn, rủi ro và phương án fallback

- **Đánh giá sơ bộ:** Khả thi trung bình do concurrency/state; cần PoC optimistic locking.
- **Giới hạn giải pháp:** Không thiết kế quy trình khiếu nại nhiều cấp trong MVP nếu giảng viên chưa bắt buộc.
- **Ước lượng thử để lập kế hoạch:** 18 giờ/người bao gồm phân tích, triển khai và test tối thiểu; **chưa phải cam kết**. Phải hiệu chỉnh theo năng lực và thời gian rảnh thực tế, xem [Capacity & Estimation](../../06-feasibility/capacity-estimation.md).
- **Tiêu chí xác nhận khả thi:** có PoC hoặc test trên dữ liệu mẫu và bằng chứng cấu hình thực; trường hợp không đạt phải nêu rõ phần cắt giảm và hỏi giảng viên nếu thuộc yêu cầu gốc.
- **Trách nhiệm quyết định:** TV1 BA/PM xác nhận nghiệp vụ, TV2 xác nhận tác động API/DB, owner module kiểm tra test, giảng viên duyệt những ràng buộc phạm vi quan trọng.

## 12. Checklist review riêng cho yêu cầu này

- [ ] Actor và quyền được mô tả rõ, có kiểm tra trái quyền.
- [ ] Tất cả bước Main Flow có trạng thái dữ liệu sau bước.
- [ ] Có ít nhất một happy case và các unhappy case thực tế ở mục 5.
- [ ] Đã đối chiếu BR với thể lệ cuộc thi hoặc có quyết định `TBD`.
- [ ] Entity và khóa tham chiếu khớp Data Dictionary.
- [ ] Mỗi AC có test dự kiến, chưa nhầm test design với test pass.
- [ ] Link Jira chính thức, PR, demo, test được cập nhật khi có.
- [ ] Được owner + reviewer chéo duyệt, trạng thái chuyển sang APPROVED.

**Chứng cứ liên kết:** [SRS Index](../README.md) · [Requirements Management](../../01-governance/requirements-management.md) · [Traceability](../../04-traceability/requirements-matrix.md) · [Feasibility](../../06-feasibility/feasibility-study.md).
