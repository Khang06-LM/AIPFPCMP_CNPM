# FR-03 — Tạo và cấu hình cuộc thi, hạng mục, vòng và tiêu chí chấm

> **Trạng thái:** DRAFT / REVIEW REQUIRED · **Bản:** 0.9 · **Ngày chuẩn bị:** 28/10/2026  
> **Đây là đặc tả yêu cầu đề xuất, KHÔNG phải chức năng đã triển khai hoặc kết quả kiểm thử đã đạt.**

## 1. Thẻ nhận diện, truy vết và nguồn gốc

| Thuộc tính | Nội dung |
| --- | --- |
| ID | FR-03 |
| Nhóm nghiệp vụ | Core Flow 1 |
| Người dùng/actor | Contest Organizer |
| Chủ sở hữu tài liệu | TV4 – Nguyễn Khánh Hiền |
| Mức ưu tiên đề xuất | MUST – lõi |
| Jira trong kế hoạch (chưa xác nhận key thực) | FPC-13; FPC-14; FPC-15; FPC-16 |
| Nguồn và mức suy diễn | [G] Core Flow 1; [P] EP-3 |
| Phụ thuộc | FR-01 |
| Entity | Contest; Category; ContestRound; Criterion; Prize |
| Trạng thái đáp ứng | Chưa có bằng chứng triển khai, test hoặc demo – cần điền link PR / test / staging |

**Quy ước nguồn:** `[G]` = nội dung từ đề tài giảng viên; `[P]` = kế hoạch nhóm; `[D]` = phân tích/thiết kế do nhóm đề xuất, cần xác nhận. Các giới hạn số lượng, thời gian và chính sách nghiệp vụ không ghi trong G/P sẽ là **TBD**, không được trình bày như yêu cầu giảng viên đã chốt.

## 2. Vấn đề, giá trị nghiệp vụ và ranh giới

**Vấn đề cần giải quyết:** Trong quy trình thu bài và tổ chức cuộc thi ảnh phim bằng các công cụ rời rạc, nghiệp vụ **tạo và cấu hình cuộc thi, hạng mục, vòng và tiêu chí chấm** thiếu dữ liệu và trạng thái tập trung, khó truy vết quyền và kết quả xử lý.

**Kết quả kỳ vọng:** Người dùng thuộc vai trò `Contest Organizer` thực hiện được hành vi được cấp quyền; hệ thống lưu và trả trạng thái nhất quán, có cơ sở kiểm thử, có dữ liệu phục vụ các bước nghiệp vụ sau.

**Trong phạm vi:** Tạo và cấu hình cuộc thi, hạng mục, vòng và tiêu chí chấm; xử lý đúng quyền, dữ liệu hợp lệ, trường hợp lỗi và dấu vết kiểm thử.

**Ngoài phạm vi / chỉ làm sau:** Template tái sử dụng và đa vòng nâng cao chỉ làm sau khi luồng chính ổn định.

## 3. Tiền điều kiện, dữ liệu và hậu điều kiện

### 3.1 Tiền điều kiện (Preconditions)
- Organizer đã được cấp quyền; danh mục cơ bản sẵn có.

### 3.2 Đầu vào (Inputs)
- ['tiêu đề, chủ đề, thời gian, luật, category, round, tiêu chí, trọng số, giải thưởng']
- Tất cả `user_id`, `role`, chủ sở hữu và thời gian thao tác phải được BE đối chiếu từ phiên xác thực / cơ sở dữ liệu, **không tin giá trị giả mạo từ client**.
- Dữ liệu thiếu chính sách bắt buộc hoặc ngưỡng (`TBD`) phải hỏi giảng viên/nhóm trước khi khóa Acceptance Criteria.

### 3.3 Đầu ra (Outputs)
- Thành công: `id` tài nguyên, `status`, `updated_at`, dữ liệu công khai theo quyền; frontend có thông báo hành động thành công.
- Thất bại: mã lỗi ổn định, thông điệp dễ hiểu, HTTP status phù hợp (401/403/404/409/422/5xx tùy tình huống); không rò dữ liệu nhạy cảm.
- Có bản ghi liên kết Entity: **Contest; Category; ContestRound; Criterion; Prize** theo sơ đồ đề xuất tại [Entity & Data Dictionary](../../03-domain/entities.md).

### 3.4 Hậu điều kiện (Postconditions)
- **Thành công:** trạng thái nghiệp vụ được ghi nhận nhất quán; hành động sau có thể sử dụng dữ liệu đúng quyền.
- **Thất bại:** không có tài nguyên “nửa thành công” được coi là hoàn tất; lỗi cần retry/rollback được ghi nhận và phân biệt với bài nộp/điểm số không hợp lệ.

## 4. Luồng nghiệp vụ chính (Main Success Scenario / Happy Case)

1. Organizer chọn Tạo cuộc thi và nhập thông tin cơ bản.
2. Hệ thống kiểm tra thời gian nhận bài, tên và các trường bắt buộc.
3. Organizer thêm hạng mục; khai báo tiêu chí chấm và trọng số theo hạng mục/vòng.
4. BE validate tổng trọng số theo chính sách; lưu cấu hình nháp.
5. Organizer xem bản xem trước quy chế, bấm Công bố cuộc thi.
6. Hệ thống chuyển trạng thái phù hợp, cho phép Participant xem và đăng ký khi đúng thời điểm.

**Kết quả quan sát được khi demo:** người phụ trách thao tác theo từng bước; mở dữ liệu kết quả hoặc nhật ký API để chứng minh trạng thái, quan hệ Entity và quyền truy cập đã thay đổi chính xác.

## 5. Các luồng thay thế, ngoại lệ và Unhappy Case

| Mã nhánh | Điều kiện kích hoạt | Xử lý bắt buộc | Kết quả/hậu điều kiện |
| --- | --- | --- | --- |
| EX-FR-03-01 | Ngày đóng trước ngày mở | Chặn lưu/publish và đánh dấu trường thời gian. | Không tạo lịch phi logic. |
| EX-FR-03-02 | Tổng trọng số không hợp lệ | Hiển thị tổng và yêu cầu sửa; ví dụ tổng 100% nếu chốt chính sách. | Không chấm bằng cấu hình sai. |
| EX-FR-03-03 | Thiếu hạng mục | Không cho công bố, vẫn giữ nháp. | Contest ở DRAFT. |
| EX-FR-03-04 | Sửa tiêu chí sau khi đã chấm | Chặn hoặc bắt đầu version mới sau phê duyệt; không ghi đè điểm cũ. | Dữ liệu chấm lịch sử nhất quán. |
| EX-FR-03-05 | Organizer sửa cuộc thi không thuộc quyền | Trả 403 hoặc 404 theo chính sách. | Không thay đổi bản ghi. |

**Nguyên tắc kiểm soát lỗi:** Đối với các nhánh trên, nhóm cần có test kiểm chứng cả ở tầng UI và API. FE chỉ giúp người dùng hiểu lỗi; **BE mới là nơi chặn thao tác không hợp lệ**. Nếu có lỗi phụ thuộc bên ngoài (AI/cloud), tuyệt đối không quy kết ngay người dùng gian lận hoặc sai dữ liệu.

## 6. Quy tắc nghiệp vụ và điều kiện còn phải quyết định

1. **[D – đề xuất, cần duyệt]** BR-08: close_at phải lớn hơn open_at; mốc thời gian lưu cùng timezone chuẩn.
2. **[D – đề xuất, cần duyệt]** BR-09: Không cho thay đổi tùy tiện tiêu chí khi đã phát sinh điểm; dùng phiên bản hoặc khóa.
3. **[D – đề xuất, cần duyệt]** BR-10: Không công bố cuộc thi chưa đủ hạng mục/quy chế tối thiểu.
4. **[D – đề xuất, cần duyệt]** BR-11: Quyền sửa cuộc thi thuộc Organizer được phân công hoặc Admin theo chính sách.

**Chốt rule:** Mỗi Business Rule (BR) trên phải có người xác nhận. Khi đổi rule, cập nhật file này, [Business Rules](../../03-domain/business-rules.md), Test Case và Jira Story liên quan bằng Pull Request.

## 7. Dữ liệu, quyền và tích hợp với các chức năng khác

- **Entities tham gia:** `Contest; Category; ContestRound; Criterion; Prize`. Xem [Entity Catalogue](../../03-domain/entities.md) và [Data Dictionary](../../03-domain/data-dictionary.md).
- **Dependency trước:** [FR-01](../functional/FR-01-authentication-rbac.md).
- **Dependency sau:** kiểm tra trong [Ma trận truy vết](../../04-traceability/requirements-matrix.md) và [Luồng nghiệp vụ](../../00-overview/end-to-end-flows.md).
- **Quyền:** BE kiểm tra actor role, trạng thái đối tượng, phạm vi contest và owner/assignment trước khi đọc hoặc sửa dữ liệu.
- **Nguyên tắc đồng nhất:** khóa ngoại không được đứt; tránh retry sinh bản ghi trùng; mọi transition quan trọng có thời gian, actor và lịch sử kiểm toán phù hợp.

## 8. Hướng đáp ứng bằng phần mềm — thiết kế đề xuất (không phải đã code)

**API dự kiến:** `POST /contests; PATCH /contests/{id}; POST /contests/{id}/publish; CRUD /categories/criteria (đề xuất)`.

1. **FE** thể hiện đúng trạng thái tải/trống/thành công/lỗi, disable nút không hợp lệ nhưng không thay thế kiểm tra BE; mapping trường đầu vào vào payload thống nhất.
2. **BE** kiểm tra JWT/RBAC, ràng buộc dữ liệu, state transition, transaction/idempotency khi cần; trả lỗi machine-readable và không ghi secret trong log.
3. **DB / Storage** sử dụng các FK/unique/version và giới hạn truy cập trong [Data Dictionary](../../03-domain/data-dictionary.md). Với ảnh, tách metadata trong DB và binary trong object storage.
4. **Integration** ghi rõ điểm gọi sang module khác, contract request/response và failure fallback; việc nào chưa có endpoint phải ghi `TBD`, không bịa API đã chạy.

**Dấu hiệu đáp ứng thực tế khi hoàn thiện:** link PR merged + commit + CI xanh + bộ test thực chạy + màn hình/demo trên staging + bản ghi bằng chứng. Hiện thời **CHƯA CÓ** các bằng chứng này trong hai tài liệu nguồn.

## 9. Acceptance Criteria (tiêu chí nghiệm thu)

| Mã | Điều kiện đạt (quan sát/kiểm thử được) | Cách chứng minh dự kiến |
| --- | --- | --- |
| AC-FR-03-01 | Có thể tạo cuộc thi nháp đầy đủ metadata. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-03-02 | Thời gian ngược bị từ chối. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-03-03 | Không thể công bố khi thiếu cấu hình tối thiểu. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-03-04 | Thay đổi tiêu chí sau thời điểm chấm không làm sai điểm lịch sử. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-03-05 | Participant nhìn thấy cuộc thi đã công bố trong danh sách. | Test qua UI + API/DB với dữ liệu kiểm soát; chụp log và kết quả mong đợi |
| AC-FR-03-06 | Khi ngày đóng trước ngày mở, hệ thống phải: Chặn lưu/publish và đánh dấu trường thời gian. Kết quả: Không tạo lịch phi logic. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-03-07 | Khi tổng trọng số không hợp lệ, hệ thống phải: Hiển thị tổng và yêu cầu sửa; ví dụ tổng 100% nếu chốt chính sách. Kết quả: Không chấm bằng cấu hình sai. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-03-08 | Khi thiếu hạng mục, hệ thống phải: Không cho công bố, vẫn giữ nháp. Kết quả: Contest ở DRAFT. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-03-09 | Khi sửa tiêu chí sau khi đã chấm, hệ thống phải: Chặn hoặc bắt đầu version mới sau phê duyệt; không ghi đè điểm cũ. Kết quả: Dữ liệu chấm lịch sử nhất quán. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |
| AC-FR-03-10 | Khi organizer sửa cuộc thi không thuộc quyền, hệ thống phải: Trả 403 hoặc 404 theo chính sách. Kết quả: Không thay đổi bản ghi. | Test unhappy với trigger tương ứng; xác nhận DB không phát sinh trạng thái sai |

> Chưa đánh dấu `Pass` cho bất kỳ AC nào trước khi chạy test thật. Sau khi làm phần mềm, điền `Expected / Actual / Evidence / Pass-Fail / Tester / Date` trong nhật ký test.

## 10. Test Scenarios (cả happy và unhappy)

| Test ID | Nhóm | Dữ liệu / thao tác | AC tham chiếu dự kiến | Kết quả mong đợi |
| --- | --- | --- | --- | --- |
| TC-FR-03-01 | Happy | Điều kiện đầu đáp ứng; thực hiện đầy đủ main flow | AC-FR-03-01 | Thao tác thành công, bản ghi đúng quyền, trạng thái hợp lệ |
| TC-FR-03-02 | Unhappy / alternate | Ngày đóng trước ngày mở | AC-FR-03-06 | Không tạo lịch phi logic. |
| TC-FR-03-03 | Unhappy / alternate | Tổng trọng số không hợp lệ | AC-FR-03-07 | Không chấm bằng cấu hình sai. |
| TC-FR-03-04 | Unhappy / alternate | Thiếu hạng mục | AC-FR-03-08 | Contest ở DRAFT. |
| TC-FR-03-05 | Unhappy / alternate | Sửa tiêu chí sau khi đã chấm | AC-FR-03-09 | Dữ liệu chấm lịch sử nhất quán. |
| TC-FR-03-06 | Unhappy / alternate | Organizer sửa cuộc thi không thuộc quyền | AC-FR-03-10 | Không thay đổi bản ghi. |

**Hướng test:** chuẩn bị seed có ID rõ ràng; chạy happy case, lỗi validation, lỗi phân quyền, lỗi trạng thái và lỗi dịch vụ phụ thuộc; lưu ảnh màn hình/log (ẩn thông tin nhạy cảm). Test Case chi tiết chính thức được theo dõi tại [Test Matrix](../../05-quality/test-matrix.md).

## 11. Khả thi, giới hạn, rủi ro và phương án fallback

- **Đánh giá sơ bộ:** Khả thi trung bình vì trạng thái và tiêu chí động; MVP một cuộc thi/1 vòng trước, thiết kế dữ liệu mở rộng.
- **Giới hạn giải pháp:** Template tái sử dụng và đa vòng nâng cao chỉ làm sau khi luồng chính ổn định.
- **Ước lượng thử để lập kế hoạch:** 24 giờ/người bao gồm phân tích, triển khai và test tối thiểu; **chưa phải cam kết**. Phải hiệu chỉnh theo năng lực và thời gian rảnh thực tế, xem [Capacity & Estimation](../../06-feasibility/capacity-estimation.md).
- **Tiêu chí xác nhận khả thi:** có PoC hoặc test trên dữ liệu mẫu và bằng chứng cấu hình thực; trường hợp không đạt phải nêu rõ phần cắt giảm và hỏi giảng viên nếu thuộc yêu cầu gốc.
- **Trách nhiệm quyết định:** TV1 BA/PM xác nhận nghiệp vụ, TV2 xác nhận tác động API/DB, owner module kiểm tra test, giảng viên duyệt những ràng buộc phạm vi quan trọng.

## 12. Checklist review riêng cho yêu cầu này

- [ ] Actor và quyền được mô tả rõ, có kiểm tra trái quyền.
- [ ] Tất cả bước Main Flow có trạng thái dữ liệu sau bước.
- [ ] Có ít nhất một happy case và các unhappy case thực tế ở mục 5.
- [ ] Đã đối chiếu BR với thể lệ cuộc thi hoặc có quyết định `TBD`.
- [ ] Entity và khóa tham chiếu khớp Data Dictionary.
- [ ] Mỗi AC có test dự kiến, chưa nhầm test design với test pass.
- [ ] Link Jira chính thức, PR, demo, test được cập nhật khi có.
- [ ] Được owner + reviewer chéo duyệt, trạng thái chuyển sang APPROVED.

**Chứng cứ liên kết:** [SRS Index](../README.md) · [Requirements Management](../../01-governance/requirements-management.md) · [Traceability](../../04-traceability/requirements-matrix.md) · [Feasibility](../../06-feasibility/feasibility-study.md).
